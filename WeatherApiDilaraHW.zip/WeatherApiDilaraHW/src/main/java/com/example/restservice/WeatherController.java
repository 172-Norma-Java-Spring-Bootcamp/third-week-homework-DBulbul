package com.example.restservice;

import com.example.restservice.exceptions.WeatherControllerException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.validation.constraints.NotNull;


@RestController
public class WeatherController {

    String key = "fd03d96f0df600554ec5234788a97d98";

    @GetMapping("/weather/current")
    public String current(@RequestParam(value = "location") String location) {
            RestTemplate restTemplate = new RestTemplate();
            String fooResourceUrl = "http://api.openweathermap.org/data/2.5/weather?q=" + location + "&appid=" + key;
            ResponseEntity<String> exchange
                    = restTemplate.getForEntity(fooResourceUrl, String.class);
            System.out.println(exchange.getBody());
            return exchange.toString();

        }
    }

