package com.example.restservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherApiDilaraHwApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherApiDilaraHwApplication.class, args);
    }

}
